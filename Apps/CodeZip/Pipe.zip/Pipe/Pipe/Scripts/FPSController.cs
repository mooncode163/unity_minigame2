﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FPSController : MonoBehaviour
{
    void Awake()
    {
        Application.targetFrameRate = 60;
    }
}
