﻿using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System.Text;
public class GameData 
{ 
   public float timeDelayGameScreen = 0;
    public int percentCompleted;
    static private GameData _main = null;
    public static GameData main
    {
        get
        {
            if (_main == null)
            {
                _main = new GameData();
            }
            return _main;
        }
    } 
}
