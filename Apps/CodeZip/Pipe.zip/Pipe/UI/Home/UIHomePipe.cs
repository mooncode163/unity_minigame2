﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIHomePipe : UIHomeBase//, ISysImageLibDelegate
{
    public GameObject objLogo;

    public void Awake()
    {

        base.Awake();

        
        // TextureUtil.UpdateRawImageTexture(imageBg, AppRes.IMAGE_HOME_BG, true);
        string appname = Common.GetAppNameDisplay();
        textTitle.text = appname;


        // LayOutSize ly = imageBgName.GetComponent<LayOutSize>();
        // if (Device.isLandscape)
        // {
        //     ly.ratioW = 0.6f;
        //     ly.ratioH = 0.8f;
        // }
        // else
        // {
        //     ly.ratioW = 0.8f;
        //     ly.ratioH = 0.6f;
        // }

        LoadCenterBar();
        LoadSideBar();
        LoadPrefab();
       
       LayOutBetween ly = objLogo.GetComponent<LayOutBetween>();
       ly.targetMain = uiHomeCenterBar.gameObject;

       LayOut();
    }

    // Use this for initialization
    public void Start()
    {
        base.Start();
        LayOut();

        OnUIDidFinish(0.5f);
    }

    // Update is called once per frame
    void Update()
    {
        UpdateBase();
    }



    public override void LayOut()
    {
        base.LayOut();
        Vector2 sizeCanvas = this.frame.size;
        float x = 0, y = 0, w = 0, h = 0;
        uiHomeCenterBar.LayOut();
        base.LayOut();
    }
    void LoadPrefab()
    {

    }
}
