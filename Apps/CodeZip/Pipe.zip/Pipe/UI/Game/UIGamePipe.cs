﻿using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
public class UIGamePipe : UIGameBase//, IGamePipeDelegate
{
    GamePipe gamePrefab;
    public GamePipe gamePipe; 
        UIGameBg gameBgPrefab;

         public GameObject objTopBar;
    static private UIGamePipe _main = null;
    public static UIGamePipe main
    {
        get
        {
            if (_main == null)
            {

            }
            return _main;
        }

    }
    public void Awake()
    {
        base.Awake();
        LoadPrefab();
        if(GameManager.main.isLoadGameScreenShot)
        {
            objTopBar.SetActive(false);
        }
        _main = this;
    }
    // Use this for initialization
    public void Start()
    {
        base.Start();
        LayOut();
        UpdateGuankaLevel(LevelManager.main.gameLevel);
    
    
        OnUIDidFinish(GameData.main.timeDelayGameScreen);
    }

    private void OnDestroy()
    {
        AppSceneBase.main.mainCamera.gameObject.SetActive(true);
    }
 
    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyUp(KeyCode.Escape))
        {
            OnClickBtnBack();
        }

    }

    void LoadPrefab()
    {

        {
            GameObject obj = PrefabCache.main.LoadByKey("GamePipe");
            if (obj != null)
            {
                gamePrefab = obj.GetComponent<GamePipe>();
            }

        }
        {
            GameObject obj = PrefabCache.main.LoadByKey("UIGameBg");
            if (obj != null)
            {
                gameBgPrefab = obj.GetComponent<UIGameBg>();
            }

        }


    }
 

    public override void UpdateGuankaLevel(int level)
    {
        base.UpdateGuankaLevel(level);

        //   WordItemInfo info = (WordItemInfo)GameLevelParse.main.GetGuankaItemInfo(level);
        AppSceneBase.main.ClearMainWorld();



        // AppSceneBase.main.UpdateWorldBg("BgGreen",true);
        // return;
        {

            UIGameBg gameBg = (UIGameBg)GameObject.Instantiate(gameBgPrefab);
            AppSceneBase.main.AddObjToMainWorld(gameBg.gameObject);

            gamePipe = (GamePipe)GameObject.Instantiate(gamePrefab);
            AppSceneBase.main.AddObjToMainWorld(gamePipe.gameObject);



            //  gamePipe.transform.localPosition = new Vector3(0f, 0f, -1f);
            // UIViewController.ClonePrefabRectTransform(gamePrefab.gameObject, gamePipe.gameObject);
        }
        AppSceneBase.main.mainCamera.gameObject.SetActive(false);


    }
    public override void LayOut()
    {
        base.LayOut();

    }

    public void OnGameFinish(bool isWin)
    {
        if(GameManager.main.isLoadGameScreenShot)
        {
            return;
        }
        string key = isWin ? "UIGameWin" : "UIGameFail";
        // key  =  "UIGameWin";
        string strPrefab = ConfigPrefab.main.GetPrefab(key);

        PopUpManager.main.Show<UIViewPop>(strPrefab, popup =>
     {
         Debug.Log("OnGameFinish Open ");
         if (!isWin)
         {
             ShowAdInsert(GAME_AD_INSERT_SHOW_STEP, true);
         }

     }, popup =>
     {


     });



    }

}
