﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.EventSystems;
using LitJson;
public class GamePipe : UIView
{ 
    static private GamePipe _main = null;
    public static GamePipe main
    {
        get
        {
            if (_main == null)
            {

            }
            return _main;
        }

    }
    public void Awake()
    {
        base.Awake();
        _main = this;
        LoadPrefab(); 
    }
    // Use this for initialization
    public void Start()
    {
        base.Start(); 
        LayOut();
    }


    void LoadPrefab()
    {


    }

    public override void LayOut()
    {
        base.LayOut();
        float x, y, w, h;
    }
}
