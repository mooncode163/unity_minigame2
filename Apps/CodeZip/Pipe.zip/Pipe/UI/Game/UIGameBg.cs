﻿using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
public class UIGameBg : UIView//, IGamePipeDelegate
{
    public UISprite uiBg;
    public Camera camera;
    public void Awake()
    {
        base.Awake();

    }
    // Use this for initialization
    public void Start()
    {
        base.Start();
        LayOut();

    }
    public override void LayOut()
    {
        base.LayOut();
        Vector2 wordsize = CameraUtil.GetWorldSize(camera, uiBg.transform.position.z - camera.transform.position.z);

        {
            RectTransform rectTransform = uiBg.GetComponent<RectTransform>();
            float w_image = rectTransform.rect.width;
            float h_image = rectTransform.rect.height;
            float scalex = wordsize.x / w_image;
            float scaley = wordsize.y / h_image;
            float scale = Mathf.Max(scalex, scaley);
            uiBg.transform.localScale = new Vector3(scale, scale, 1.0f);
        }

    }


}
