
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using Vectrosity;
public class BoardLine : UIView
{
 
    public void Awake()
    {
        this.gameObject.name = GameMerge.NameBoardLine;

    }


    public void Start()
    {
         
    }

 

}

