
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using Vectrosity;
public class UIBoard : UIView
{ 
    /// Awake is called when the script instance is being loaded.
    /// </summary>
    public void Awake()
    {
  
    }


    public void Start()
    {
    
    }

 

}

